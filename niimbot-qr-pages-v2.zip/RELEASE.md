# Release v2

- Shortcut-/URL-API (`#qr=...`, `text`, `copies`, `density`, `offset`, `ecc`, `autoprint`)
- Sofortige Vorschau beim Öffnen
- `autoprint=1`: Druck nach Benutzeraktion „B1 verbinden“ automatisch fortsetzen
- GitHub-Pages-Workflow mit verständlichem First-Setup-Check
- `upload-pages-artifact` auf v4 aktualisiert
- Service-Worker-Cache v2
